dd if=/dev/mtd2 of=/tmp/firmware.bin
