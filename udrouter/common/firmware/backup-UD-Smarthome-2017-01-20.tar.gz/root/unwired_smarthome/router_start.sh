#!/bin/sh
lua /root/unwired_smarthome/router.lua
exec sh