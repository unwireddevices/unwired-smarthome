fw_setenv silent 1
